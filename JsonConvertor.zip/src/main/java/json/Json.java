package json;

/**
 * Created by Andrii_Rodionov on 1/3/2017.
 */
public abstract class Json {
    public abstract String toJson();
}
